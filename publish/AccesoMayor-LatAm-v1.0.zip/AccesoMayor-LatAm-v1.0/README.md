# AccesoMayor-LatAm v1.0 (IEEE DataPort package)

Accessibility, mobile-performance, and Spanish-readability audits of essential-service websites older adults use in Latin America (10 countries × 5 sectors; deep El Salvador stratum).

Entry for the **IEEE AgeTech Global Dataset Competition 2026**.

## What is in this zip
| path | rows (excl. header) | notes |
|---|---|---|
| `data/sampling_frame.csv` | 148 | sites |
| `data/page_frame.csv` | 225 | home + task pages |
| `data/page_frame_dropped.csv` | 27 | curation drops |
| `data/full_run/pages.csv` | 225 | audited page snapshots |
| `data/full_run/violations.csv` | 650 | axe rule × WCAG SC |
| `data/full_run/run_log.csv` | 225 | one row per attempted URL |
| `data/data_dictionary.csv` | 58 | field dictionary |
| `data/schema.md` | — | published schema |
| `pipeline/schema/*.json` | — | JSON Schema 2020-12 |
| `ETHICS.md` | — | public pages only; no HTML dumps |

## Reproduce
Full runner (pinned deps) lives in the public repo: https://github.com/jaime-sql/accesomayor-latam

```bash
git clone https://github.com/jaime-sql/accesomayor-latam.git
cd accesomayor-latam/pipeline
./run.sh ../data/page_frame.csv out/
```

Requires Node 20+ and Python 3.12+. See `pipeline/README.md`.

## License
CC BY 4.0 — see `LICENSE`.
